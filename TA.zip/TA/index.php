<?php
include "koneksi.php";

$sqlCommand2 = "SELECT * FROM api ORDER BY waktu DESC LIMIT 1";
$query2 = mysqli_query($conn, $sqlCommand2);
$row1 = mysqli_fetch_row($query2);

echo "<script>console.log('Query Result: " . json_encode($row1) . "');</script>";

$api = $row1[1];
$asap = $row1[2];
$status = $row1[3];
$status2 = $row1[4];
$waktu = $row1[5];
?>
<!DOCTYPE html>
<html>

<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">

    <!-- <title>GAS DETECTION DEVICE</title> -->

    <!-- Favicon -->
    <link href="./assets/img/brand/G2D.jpg" rel="icon" type="image/png">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

    <!-- Icons -->
    <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
    <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">

    <!-- Argon CSS -->
    <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">
</head>

<body class="bg-gradient-green">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Gas Detection</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">History</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Konten utama -->
    <div class="main-content">
        <!-- Header -->
        <div class="header bg-gradient-success pb-8 pt-5 pt-md-5" style="height: 100vh;">
            <div class="container-fluid">
                <div class="header-body">
                    <h1 class="row justify-content-center mt-4" style="font-size: 5em;">Gas Detection Device</h1>

                    <!-- Statistik Kartu -->
                    <div class="row pt-4">
                        <div class="col-xl-4 col-lg-8 offset-lg-2">
                            <div class="card card-stats mb-4 mb-xl-0">
                                <div class="card-body">
                                    <div class="row">                                        
                                    <div class="col text-center">
                                            <h1 class="card-title text-uppercase text-muted mb-0" style="font-size: 3em;"><?php echo $status; ?></h1>
                                            <?php if ($api == 0) { ?>
                                                <div class="alert alert-success" role="alert">
                                                    <span class="h1 font-weight-bold mb-0" style="font-size: 2em;"> TERDETEKSI AMAN</span>
                                                </div>
                                            <?php } elseif ($api == 1) { ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <span class="h1 font-weight-bold mb-0" style="font-size: 2em;">KEBOCORAN GAS</span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">RUANGAN TERBUKA</h5>
                                            <span class="h2 font-weight-bold mb-0"><?php echo $api; ?> PPM</span>
                                        </div>
                                        <div class="col-auto">
                                            <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                                                <i class="fas fa-exclamation"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="mt-3 mb-0 text-muted text-sm">
                                        <span class="text-warning mr-2"><i class="fas fa-arrow-down"></i> WAKTU</span>
                                        <span class="text-nowrap"><?php echo $waktu; ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-8">
                            <div class="card card-stats mb-4 mb-xl-0">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col text-center">
                                            <h1 class="card-title text-uppercase text-muted mb-0"
                                                style="font-size: 3em;"><?php echo $status2; ?></h1>
                                            <?php if ($asap <= 750) { ?>
                                            <div class="alert alert-success" role="alert">
                                                <span class="h1 font-weight-bold mb-0"
                                                    style="font-size: 2em;">IDLE</span>
                                            </div>
                                            <?php } elseif ($asap > 750 && $asap <= 900) { ?>
                                            <div class="alert alert-warning" role="alert">
                                                <span class="h1 font-weight-bold mb-0"
                                                    style="font-size: 2em;"> TERDETEKSI AMAN</span>
                                            </div>
                                            <?php } elseif ($asap > 900) { ?>
                                            <div class="alert alert-danger" role="alert">
                                                <span class="h1 font-weight-bold mb-0"
                                                    style="font-size: 2em;">KEBOCORAN GAS</span>
                                            </div>
                                            <?php } elseif ($asap < 500) { ?>
                                            <div class="alert alert-success" role="alert">
                                                <span class="h1 font-weight-bold mb-0"
                                                    style="font-size: 2em;">- - -</span>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <h5 class="card-title text-uppercase text-muted mb-0">RUANGAN TERTUTUP
                                            </h5>
                                            <span class="h2 font-weight-bold mb-0"><?php echo $asap; ?> PPM</span>
                                            <span class="h2 font-weight-bold mb-0">
                                            </span>
                                        </div>
                                        <div class="col-auto">
                                            <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                                                <i class="fas fa-exclamation"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="mt-3 mb-0 text-muted text-sm">
                                        <span class="text-warning mr-2"><i class="fas fa-arrow-down"></i> WAKTU</span>
                                        <span class="text-nowrap"><?php echo $waktu; ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center mt-4">
                        <div class="col-lg-4">
                            <div class="text-right">
                                <a href="history.php" class="btn btn-primary btn-lg">Lihat History</a>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="text-left">
                                <button id="idleButton" class="btn btn-danger btn-lg">Normal Idle</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('idleButton').addEventListener('click', function (event) {
            event.preventDefault();
            setIdle();
        });

        function setIdle() {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "set_idle.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    console.log("AJAX request completed with status: " + xhr.status);
                    if (xhr.status === 200) {
                        console.log("Response: " + xhr.responseText);
                        location.reload(); // Refresh the page to show the updated status
                    } else {
                        console.error("Failed to set idle status. Response: " + xhr.responseText);
                    }
                }
            };
            xhr.send(); // Send the POST request
        }

        // Auto-refresh the page every 3 seconds
        function autoRefresh() {
            setTimeout(function () {
                location.reload();
            }, 3000); // Refresh every 3 seconds
        }
        autoRefresh();
    </script>
</body>

</html>
