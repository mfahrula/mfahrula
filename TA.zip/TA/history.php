<!DOCTYPE html>
<html>

<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">

    <title>Tabel Hasil</title>

    <!-- Favicon -->
    <link href="./assets/img/brand/G2D.jpg" rel="icon" type="image/png">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

    <!-- Icons -->
    <link href="./assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
    <link href="./assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">

    <!-- Argon CSS -->
    <link type="text/css" href="./assets/css/argon.css?v=1.0.0" rel="stylesheet">

    <style>
        /* CSS untuk membuat tabel memiliki scroll vertikal */
        .table-responsive {
            max-height: 400px; /* Ganti dengan tinggi yang sesuai */
            overflow-y: auto;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Gas Detection</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main content -->
    <div class="main-content">
        <!-- Header -->
        <div class="header bg-gradient-green pb-8 pt-5 pt-md-8" style="height: 100vh;">
            <div class="container-fluid">
                <div class="header-body">
                    <!-- Tabel Hasil -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3 class="mb-0 text-center">Riwayat Kebocoran</h3>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush text-center">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Waktu</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Ruangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php  
                                    include "koneksi.php";
                                    $sqlCommand = "SELECT * FROM `history` ORDER BY `waktu` DESC";
                                    $query = mysqli_query($conn, $sqlCommand);
                                    while ($row = mysqli_fetch_assoc($query)) {
                                        $tanggal = date('d-m-Y', strtotime($row['waktu']));
                                        $waktu = date('H:i:s', strtotime($row['waktu']));
                                    ?>
                                    <tr>
                                        <td><?php echo $tanggal; ?></td>
                                        <td><?php echo $waktu; ?></td>
                                        <td><?php echo $row['status']; ?></td>
                                        <td><?php echo $row['ruangan']; ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-center">
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                                <button type="submit" class="btn btn-danger" name="reset_history">Reset History</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="./assets/vendor/jquery/dist/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="./assets/vendor/chart.js/dist/Chart.extension.js"></script>
    <script src="./assets/js/argon.js?v=1.0.0"></script>
</body>

</html>

<?php
include "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["reset_history"])) {
    $delete_query = "DELETE FROM `history`";
    $result = mysqli_query($conn, $delete_query);

    if ($result) {
        header("Refresh:3");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
