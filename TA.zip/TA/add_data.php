<?php 
include "koneksi.php";
date_default_timezone_set('Asia/Jakarta');

if(isset($_GET['asap1']) && isset($_GET['asap2'])) {
    $asap1 = $_GET['asap1'];
    $asap2 = $_GET['asap2'];

    echo "asap1: $asap1, asap2: $asap2";
 
    if ($asap1 = 1) {
        $status1 = 'AMAN';
    } else {
        $status1 = 'GAS BOCOR';
    }

    if ($asap2 <= 750) {
        $status2 = 'IDLE';
    } elseif ($asap2 > 750 && $asap2 <= 900) {
        $status2 = "AMAN";
    } elseif ($asap2 > 900) {
        $status2 = "GAS BOCOR";
    } else {
        $status2 = 'AMAN';
    }

    $q = "UPDATE api SET asap1 = '$asap1', asap2 = '$asap2', status1 = '$status1', status2 = '$status2', waktu = CURRENT_TIMESTAMP WHERE id = '35';";
    $ck = mysqli_query($conn, $q);

    // if ($status1 === 'GAS BOCOR' || $status2 === 'KEBOCORAN GAS' ) {
        $insert_history_query = "INSERT INTO history (status, waktu, ruangan) VALUES ('$status1', CURRENT_TIMESTAMP, 'Terbuka'), ('$status2', CURRENT_TIMESTAMP, 'Tertutup');";
        mysqli_query($conn, $insert_history_query);
    // }
} else {
    echo "Parameter 'asap1' dan 'asap2' tidak diterima.";
}
?>