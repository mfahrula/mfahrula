<?php
include "koneksi.php";
date_default_timezone_set('Asia/Jakarta');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $q = "UPDATE api SET asap1 = '0', asap2 = '0', status1 = 'AMAN', status2 = 'IDLE', waktu = CURRENT_TIMESTAMP WHERE id = '35';";
    $ck = mysqli_query($conn, $q);

    if ($ck) {
        echo "Status berhasil diatur ke IDLE.";
    } else {
        echo "Gagal mengatur status ke IDLE.";
    }
} else {
    echo "Permintaan tidak valid.";
}
?>
